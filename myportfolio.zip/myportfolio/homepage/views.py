from django.shortcuts import render
from homepage.models import Project

# Create your views here.

# function to showcase all the prjects in one view
def project_index(request):
    projects = Project.objects.all()

    context = {
        'projects': projects
    }
    return render(request, "project_index.html", context)


# define a function which take you through each project details
def project_detail(request, pk):
    project = Project.objects.get(pk=pk)

    context = {
        'project': project
    }

    return render(request, "project_detail.html", context)