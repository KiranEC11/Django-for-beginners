from django.shortcuts import render
from blog.models import Post,Comment
from blog.forms import CommentForm
# Create your views here.

#post comments are not displayed in blog_index and blog_category view.
# it is shown only in the blog_detail view.
def blog_index(request):
    posts = Post.objects.all().order_by("-created_on")
    context = {
        "posts" : posts,
    }
    return render(request, "blog_index.html", context)


# create a view function which filter the posts based on given
#category

def blog_category(request, category):
    posts = Post.objects.filter(
        categories__name__icontains= category
        ).order_by(
        "-created_on"
        )
    
    context = {
        "category": category,
        "posts":posts,
    }

    return render(request, "blog_category.html", context )

def blog_detail(request, pk):
    post = Post.objects.get(pk = pk)

    """
    when a form is posted, a POST request is sent to the server.
    so in the view function we need to check if a POST request
    has been received or not. if received we need to check 
    if all the fields are correctly filled using 
    -->form.is_valid():<--
    after that create another instance of Comment class. 
    after that save the new instance.

    form.cleaned_data is a dictionary. 
    They keys of the dictionary correspond to the form fields.
    """
    form = CommentForm()
    if request.method =='POST':
        form = CommentForm(request.POST)
        if form.is_valid():  # check if all the fields are correctly entered.
            comment = Comment(
                author = form.cleaned_data['author'],
                body = form.cleaned_data['body'],
                post=post
            )
            comment.save()

    comments = Comment.objects.filter(post = post)
    context = {
        "post": post,
        "comments": comments,
        "form": form,
    }
    # add the form to the context dictionary so you can 
    # #access the form in the HTML template.    
    return render(request, "blog_detail.html", context)
