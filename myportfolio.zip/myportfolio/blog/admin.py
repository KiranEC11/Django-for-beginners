from django.contrib import admin
from blog.models import Post, Category 

#you don't have to edit or create comment, hence no need
#to register it to admin. if you want to moderate the comments
#then you can import and register the Comment class to admin.

# Register your models here.
class PostAdmin(admin.ModelAdmin):
    pass

class CategoryAdmin(admin.ModelAdmin):
    pass

admin.site.register(Post, PostAdmin)
admin.site.register(Category, CategoryAdmin)

